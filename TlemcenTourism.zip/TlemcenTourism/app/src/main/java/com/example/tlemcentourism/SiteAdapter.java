package com.example.tlemcentourism;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

/**
 * {@link SiteAdapter} is an {@link ArrayAdapter} that can provide the layout for each list item
 * based on a data source, which is a list of {@link Site} objects.
 */
public class SiteAdapter extends ArrayAdapter<Site> {
    public static final String LOG_TAG = SiteAdapter.class.getName();

    /**
     * Create a new {@link SiteAdapter} object.
     *
     * @param context is the current context (i.e. Activity) that the adapter is being created in.
     * @param sites is the list of {@link Site}s to be displayed.
     */
    public SiteAdapter(Context context, List<Site> sites) {
        super(context, 0, sites);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View listItemView = convertView;
        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(
                    R.layout.single_site, parent, false);
        }

        Site currentSite = (Site) getItem(position);
        int zeName = currentSite.getmName();
        int zeTagline = currentSite.getmTagline();
        int zeDescr = currentSite.getmDescr();
        final int zeLink = currentSite.getmLink();
        int zeImage = currentSite.getmImage();

        TextView nameTV = listItemView.findViewById(R.id.name_tv);
        nameTV.setText(zeName);

        TextView priceTV = listItemView.findViewById(R.id.tagLine_tv);
        priceTV.setText(zeTagline);

        TextView linkTV = listItemView.findViewById(R.id.link_tv);
        TextView linkIntroTV = listItemView.findViewById(R.id.linkIntro_tv);
        if (zeLink == 0) {
            linkTV.setVisibility(View.GONE);
            linkIntroTV.setVisibility(View.GONE);
        } else {
            linkTV.setVisibility(View.VISIBLE);
            linkIntroTV.setVisibility(View.VISIBLE);
            linkTV.setText(zeLink);
            linkTV.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(getContext().getString(zeLink)));
                    getContext().startActivity(i);
                }
            });
        }

       TextView featuresTV = listItemView.findViewById(R.id.desc_tv);
        if (zeDescr == 0) {
            featuresTV.setVisibility(View.GONE);
        } else {
            featuresTV.setVisibility(View.VISIBLE);
            featuresTV.setText(zeDescr);
        }

        ImageView thumbIV = listItemView.findViewById(R.id.image_iv);
        if (zeImage == 0) {
            thumbIV.setVisibility(View.GONE);
        } else {
            thumbIV.setVisibility(View.VISIBLE);
            thumbIV.setImageResource(zeImage);
        }

        return listItemView;
    }
}
