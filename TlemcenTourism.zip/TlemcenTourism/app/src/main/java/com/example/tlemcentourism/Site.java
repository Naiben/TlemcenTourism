package com.example.tlemcentourism;

public class Site {
    private int mCategory;
    private int mName;
    private int mTagline;
    private int mDescr;
    private int mLink;
    private int mImage;

    public Site(int zeCategory, int zeName, int zeTagline, int zeDescr, int zeLink, int zeImage) {
        this.mCategory = zeCategory;
        this.mName = zeName;
        this.mTagline = zeTagline;
        this.mDescr = zeDescr;
        this.mLink = zeLink;
        this.mImage = zeImage;
    }


    public int getmCategory() {
        return mCategory;
    }

    public int getmName() {
        return mName;
    }

    public int getmTagline() {
        return mTagline;
    }

    public int getmDescr() {
        return mDescr;
    }

    public int getmLink() {
        return mLink;
    }

    public int getmImage() {
        return mImage;
    }

}
