package com.example.tlemcentourism;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class MusicFragment extends Fragment {


    public MusicFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        final View rootView = inflater.inflate(R.layout.site_list, container, false);
        final ArrayList<Site> sites = new ArrayList<Site>();
        sites.add(new Site(R.string.str_catMusic, R.string.str_site_music01name, R.string.str_site_music01tagLine, R.string.str_site_music01descr, R.string.str_site_music01link, R.drawable.ecole));
        sites.add(new Site(R.string.str_catMusic, R.string.str_site_music02name, R.string.str_site_music02tagLine, R.string.str_site_music02descr, R.string.str_site_music02link, R.drawable.kortobia));
        SiteAdapter adapter = new SiteAdapter(getActivity(), sites);
        ListView listView = rootView.findViewById(R.id.list);
        listView.setAdapter(adapter);
        return rootView;
    }

}
