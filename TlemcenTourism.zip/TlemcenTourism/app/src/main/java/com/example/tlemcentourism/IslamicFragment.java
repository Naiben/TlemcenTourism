package com.example.tlemcentourism;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class IslamicFragment extends Fragment {


    public IslamicFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        final View rootView = inflater.inflate(R.layout.site_list, container, false);
        final ArrayList<Site> sites = new ArrayList<Site>();
        sites.add(new Site(R.string.str_catIslamic, R.string.str_site_ih01name, R.string.str_site_ih01tagLine, R.string.str_site_ih01descr, R.string.str_site_ih01link, R.drawable.sidi));
        sites.add(new Site(R.string.str_catIslamic, R.string.str_site_ih02name, R.string.str_site_ih02tagLine, R.string.str_site_ih02descr, R.string.str_site_ih02link, R.drawable.djamaa));
        sites.add(new Site(R.string.str_catIslamic, R.string.str_site_ih03name, R.string.str_site_ih03tagLine, R.string.str_site_ih03descr, R.string.str_site_ih03link, R.drawable.belahcen));        SiteAdapter adapter = new SiteAdapter(getActivity(), sites);
        ListView listView = rootView.findViewById(R.id.list);
        listView.setAdapter(adapter);
        return rootView;
    }

}
